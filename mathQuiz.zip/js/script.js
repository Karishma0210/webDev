document.addEventListener("DOMContentLoaded",
  function (event) {
    var quizSol = [];

    // Unobtrusive event binding
    document.getElementById("startQuizB")
      .addEventListener("click", function () {
        document.getElementById("quizStarter").innerHTML = "Welcome " 
                                + document.getElementById("name").value + ", "
                                + "The quiz has been started!";
        var operations = ["+", "-", "*", "/"], questions = [];
        
        for(var i=0; i<10; i++){
          var n1 = Math.trunc(Math.random()*100, 2);
          var op = operations[Math.trunc(Math.random()*4, 2)];
          var n2 = Math.trunc(Math.random()*100, 2);
          questions[i] = n1 +" "+ op + " " + n2;
          ansPsuedoId = "ans"+(i+1);
          document.getElementById("q"+ (i+1)).innerHTML = ( questions[i] +
                                  ' = <input type="text" id="' + ansPsuedoId + '" />');
          
          quizSol.push([n1, n2, op, eval(n1 + op + n2)]);

        }

        document.getElementById("submissionArea").innerHTML = '<input type="button" id="submitQuizB" onclick="check();" value="Submit" />';
        
      });
      window.quizSol = quizSol;
      
      //document.getElementById("q1").style.backgroundColor = "green";
      //document.getElementById("submissionArea")
  }
);

//console.log(document.getElementById("submitQuizB"));
function check() {

    var qObj = document.getElementsByClassName("qSection");
    for(var i=0; i<qObj.length; i++) {
      document.getElementById( ("ans"+(i+1))).disabled="true";
      document.getElementById("submitQuizB").disabled="true";
      if(document.getElementById( ("ans"+(i+1))).value == quizSol[i][3] ) {
        qObj[i].classList.add("ansTrue");
      }
      else{
        // console.log(document.getElementById( ("ans"+(i+1))));
        // console.log(quizSol[i][3]);
        qObj[i].classList.add("ansFalse");
      }
    }
}
